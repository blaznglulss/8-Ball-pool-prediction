# Alaa-8ball-pool-source-exposed

I apologise for the name

Hello, this is just a fixed source i have nothing to do with him, atm. Have a nice day.

Photos:
https://cdn.discordapp.com/attachments/976573206360113162/983119408618692618/unknown.png
https://cdn.discordapp.com/attachments/979095925542776923/983115157246992394/unknown.png

How to use:
1. Open the sln file
2. Put Relase x64
3. do CTRL+B

I dont know if you need to update offsets anyway.

UPDATES:
V1.0 -> Posted This
